﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VendingMachine.Data;

namespace VendingMachine.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageDrinks.xaml
    /// </summary>
    public partial class PageDrinks : Page
    {
        public PageDrinks()
        {
            InitializeComponent();
            lvDrinks.ItemsSource = ClassDataBase.dbObject.Drinks.ToList();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frameObj.GoBack();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnDel_Click(object sender, RoutedEventArgs e)
        {
            Drinks drink = lvDrinks.SelectedItem as Drinks;
            if (drink == null) MessageBox.Show("Запись не выбрана!", "Ошибка удаления", MessageBoxButton.OK, MessageBoxImage.Error);
            else if (MessageBox.Show("Вы точно хотите удалить запись?\n" + drink.Name,
                "Удаление записи", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                ClassDataBase.dbObject.Drinks.Remove(drink);
                ClassDataBase.dbObject.SaveChanges();
                MessageBox.Show("Запись удалена", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                lvDrinks.ItemsSource = ClassDataBase.dbObject.Drinks.ToList();
            }
        }

        private void btnOtmend_Click(object sender, RoutedEventArgs e)
        {
            spAdd.Visibility = Visibility.Hidden;
            spEdit.Visibility = Visibility.Visible;
        }



        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            spAdd.Visibility = Visibility.Visible;
            spEdit.Visibility = Visibility.Hidden;
        }

        private void btnSaveAdd_Click(object sender, RoutedEventArgs e)
        {
            var entObj = ClassDataBase.dbObject.Drinks.FirstOrDefault(x => x.Name.ToLower() == txbName.Text.ToLower());

            if (txbName.Text.Length == 0 && txbPriceAdd.Text.Length == 0)
                MessageBox.Show("Поля не могут быть пустыми!",
                    "Критическая ошибка", MessageBoxButton.OK, MessageBoxImage.Error);

            else if (txbName.Text.Length == 0)
            {
                MessageBox.Show("Поле: 'Название' не может быть пустым!",
                    "Критическая ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                txbName.Focus();
            }

            else if (txbPriceAdd.Text.Length == 0)
            {
                MessageBox.Show("Поле: 'Цена' не может быть пустым!",
                    "Критическая ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                txbPriceAdd.Focus();
            }
            else if (entObj != null)
                MessageBox.Show("Напиток с таким именем уже есть!",
                    "Критическая ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            else
            {
                Drinks drink = new Drinks()
                {
                    Name = txbName.Text,
                    //  Image = base64
                    Cost = Convert.ToDecimal(txbPriceAdd.Text)
                };
                ClassDataBase.dbObject.Drinks.Add(drink);
                ClassDataBase.dbObject.SaveChanges();
                MessageBox.Show("Напиток успешно добавлен", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                lvDrinks.ItemsSource = ClassDataBase.dbObject.Drinks.ToList();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frameObj.GoBack();
        }
        private void btnOpenPhoto_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.FileName = "";
            dlg.Filter = "All supported graphics|*.jpg;*.jpeg;*.png|" +
         "JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|" + "Portable Network Graphic (*.png)|*.png";

            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                imgPhoto.Source = new BitmapImage(new Uri(dlg.FileName));
                lNamePhoto.Content = dlg.FileName;
            }
        }
    }
}
